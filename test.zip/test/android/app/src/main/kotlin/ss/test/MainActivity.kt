package ss.test

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
